package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.managers.LanguageManager;
import com.bltz.bltztravel.managers.SpawnManager;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetSpawnCommand implements CommandExecutor {

    private final BltzTravel plugin;

    public SetSpawnCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (!player.hasPermission("bltztravel.admin")) {
            LanguageManager lang = plugin.getLanguageManager();
            MessageUtil.send(player, lang.get("no-permission"));
            return true;
        }

        SpawnManager spawnManager = plugin.getSpawnManager();
        spawnManager.setSpawn(player.getLocation());

        LanguageManager lang2 = plugin.getLanguageManager();
        MessageUtil.send(player, lang2.get("spawn.set"));
        return true;
    }
}
