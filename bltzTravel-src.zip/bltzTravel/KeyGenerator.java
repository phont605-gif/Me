import java.security.SecureRandom;
import java.util.Scanner;

/**
 * bltzTravel Key Generator
 * Dùng để tạo key mới khi có khách mua
 * 
 * Sau khi generate key:
 * 1. Copy key vào VALID_KEYS trong LicenseManager.java
 * 2. Rebuild plugin
 * 3. Gửi key cho khách
 */
public class KeyGenerator {

    private static final String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final SecureRandom random = new SecureRandom();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║   bltzTravel License Key Generator   ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.println();

        System.out.print("Tạo bao nhiêu key? (mặc định 1): ");
        String input = scanner.nextLine().trim();
        int count = 1;
        try { count = Integer.parseInt(input); } catch (Exception ignored) {}

        System.out.println();
        System.out.println("✅ Keys mới (thêm vào VALID_KEYS trong LicenseManager.java):");
        System.out.println();

        for (int i = 0; i < count; i++) {
            String key = generateKey();
            System.out.println("  \"" + key + "\",");
        }

        System.out.println();
        System.out.println("⚠️  Nhớ rebuild plugin sau khi thêm key!");
        scanner.close();
    }

    private static String generateKey() {
        return "BLTZ-" + randomPart() + "-" + randomPart() + "-" + randomPart() + "-" + randomPart();
    }

    private static String randomPart() {
        StringBuilder sb = new StringBuilder(4);
        for (int i = 0; i < 4; i++) {
            sb.append(CHARS.charAt(random.nextInt(CHARS.length())));
        }
        return sb.toString();
    }
}
