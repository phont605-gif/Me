package com.bltz.bltztravel.license;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class LicenseManager {

    // SECRET phải giống y chang trong bot Discord
    // TUYỆT ĐỐI KHÔNG SHARE CÁI NÀY
    private static final String SECRET = "bltzTravel_2025_@bl7z_s3cr3t_x9q!";

    /**
     * Verify key trong plugin
     * Key hợp lệ nếu được generate từ đúng SECRET
     */
    public static boolean verify(String licenseKey) {
        if (licenseKey == null || licenseKey.trim().isEmpty()) return false;

        try {
            String input = licenseKey.trim().toUpperCase();
            if (!input.startsWith("BLTZ-")) return false;
            if (input.length() != 24) return false; // BLTZ-XXXX-XXXX-XXXX-XXXX = 24 chars

            // Tách raw data (16 chars không tính BLTZ- và dashes)
            String raw = input.replace("BLTZ-", "").replace("-", "");
            if (raw.length() != 16) return false;

            // Verify: tính HMAC của 12 chars cuối, so với 4 chars đầu
            String tail = raw.substring(4); // 12 chars
            String head = raw.substring(0, 4); // 4 chars (checksum)

            String expectedHead = hmac4(tail);
            return constantTimeEquals(head, expectedHead);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Generate key từ orderID
     * Dùng trong bot Discord khi có khách mua
     */
    public static String generateKey(int orderID) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec keySpec = new SecretKeySpec(
            SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
        mac.init(keySpec);

        // Tạo 12 chars từ orderID
        String data = "bltzTravel:order:" + orderID + ":" + SECRET.hashCode();
        byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        String base64 = toBase64Clean(hash);
        String tail = base64.substring(0, 12).toUpperCase();

        // Tạo 4 chars checksum từ tail
        String head = hmac4(tail);

        String raw = head + tail;
        return "BLTZ-" + raw.substring(0, 4) + "-"
                       + raw.substring(4, 8) + "-"
                       + raw.substring(8, 12) + "-"
                       + raw.substring(12, 16);
    }

    private static String hmac4(String data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec keySpec = new SecretKeySpec(
            SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
        mac.init(keySpec);
        byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return toBase64Clean(hash).substring(0, 4).toUpperCase();
    }

    private static String toBase64Clean(byte[] data) {
        return Base64.getEncoder().encodeToString(data)
            .replace("+", "A").replace("/", "B").replace("=", "");
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }
}
