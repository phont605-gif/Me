package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class DelHomeCommand implements CommandExecutor, TabCompleter {

    private final BltzTravel plugin;

    public DelHomeCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        if (args.length == 0) {
            plugin.getLanguageManager().sendMessage(player, "general.invalid-args", Map.of("usage", "/delhome <n>"));
            return true;
        }

        String homeName = args[0];
        if (!plugin.getHomeManager().deleteHome(player, homeName)) {
            plugin.getLanguageManager().sendMessage(player, "home.not-found", Map.of("name", homeName));
            return true;
        }

        plugin.getLanguageManager().sendMessage(player, "home.delete-success", Map.of("name", homeName));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return Collections.emptyList();
        if (args.length == 1) {
            List<String> names = new ArrayList<>(plugin.getHomeManager().getHomes(player).keySet());
            String input = args[0].toLowerCase();
            names.removeIf(n -> !n.startsWith(input));
            return names;
        }
        return Collections.emptyList();
    }
}
