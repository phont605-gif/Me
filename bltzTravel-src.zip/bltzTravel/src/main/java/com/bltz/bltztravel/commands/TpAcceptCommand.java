package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.TeleportRequest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class TpAcceptCommand implements CommandExecutor {

    private final BltzTravel plugin;

    public TpAcceptCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        TeleportRequest request = plugin.getTpaManager().removeRequest(player);
        if (request == null) {
            plugin.getLanguageManager().sendMessage(player, "tpa.no-request");
            return true;
        }

        if (request.isExpired(plugin.getConfigManager().getRequestTimeout())) {
            plugin.getLanguageManager().sendMessage(player, "tpa.expired");
            return true;
        }

        Player requester = request.getSender();

        plugin.getLanguageManager().sendMessage(player, "tpa.you-accepted", Map.of("player", requester.getName()));

        if (request.getType() == TeleportRequest.Type.TPA) {
            // Sender teleports to target
            plugin.getLanguageManager().sendMessage(requester, "tpa.accepted", Map.of("player", player.getName()));
            Map<String, String> ph = Map.of("delay", String.valueOf(plugin.getConfigManager().getTeleportDelay()),
                    "player", player.getName());
            plugin.getLanguageManager().sendMessage(requester, "tpa.teleporting", ph);
            plugin.getTeleportManager().teleport(requester, player.getLocation(), "tpa.teleporting", ph,
                    () -> plugin.getLanguageManager().sendMessage(requester, "tpa.teleported", Map.of("player", player.getName())),
                    null);
        } else {
            // TPAHERE - target teleports to sender
            plugin.getLanguageManager().sendMessage(requester, "tpa.accepted", Map.of("player", player.getName()));
            Map<String, String> ph = Map.of("delay", String.valueOf(plugin.getConfigManager().getTeleportDelay()),
                    "player", requester.getName());
            plugin.getLanguageManager().sendMessage(player, "tpa.teleporting", ph);
            plugin.getTeleportManager().teleport(player, requester.getLocation(), "tpa.teleporting", ph,
                    () -> plugin.getLanguageManager().sendMessage(player, "tpa.teleported", Map.of("player", requester.getName())),
                    null);
        }
        return true;
    }
}
