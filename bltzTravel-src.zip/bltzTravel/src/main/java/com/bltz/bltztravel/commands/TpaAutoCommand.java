package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TpaAutoCommand implements CommandExecutor {

    private final BltzTravel plugin;

    public TpaAutoCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        boolean nowAuto = plugin.getTpaManager().toggleTpaAuto(player);
        plugin.getLanguageManager().sendMessage(player, nowAuto ? "tpa.auto-on" : "tpa.auto-off");
        return true;
    }
}
