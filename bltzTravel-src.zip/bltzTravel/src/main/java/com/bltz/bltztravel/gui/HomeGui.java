package com.bltz.bltztravel.gui;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.Home;
import com.bltz.bltztravel.utils.MessageUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class HomeGui {
    public static final String GUI_TITLE_PREFIX = "§8Homes";
    public static final int[] HOME_SLOTS = {12, 13, 14, 15, 16, 30, 31, 32, 33, 34};
    public static final int[] ACTION_SLOTS = {21, 22, 23, 24, 25, 39, 40, 41, 42, 43};

    public static void open(BltzTravel plugin, Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, MessageUtil.colorize("&8Homes"));
        Map<Integer, Home> homes = plugin.getHomeManager().getHomes(player);
        int maxHomes = plugin.getHomeManager().getMaxHomes(player);

        // Fill with glass pane
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.displayName(Component.empty());
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < 54; i++) inv.setItem(i, filler);

        // Place home items
        for (int i = 0; i < HOME_SLOTS.length; i++) {
            int homeId = i + 1;
            int slot = HOME_SLOTS[i];
            int actionSlot = ACTION_SLOTS[i];
            boolean hasHome = homes.containsKey(homeId);
            boolean locked = homeId > maxHomes;

            // Home display item
            ItemStack homeItem;
            if (locked) {
                homeItem = new ItemStack(Material.RED_BED);
            } else if (hasHome) {
                homeItem = new ItemStack(Material.LIGHT_BLUE_BED);
            } else {
                homeItem = new ItemStack(Material.GRAY_BED);
            }
            ItemMeta meta = homeItem.getItemMeta();
            if (locked) {
                meta.displayName(MessageUtil.colorize("&#FF0812Home #" + homeId));
                meta.lore(List.of(MessageUtil.colorize("&cNo permission: bltztravel.home." + homeId)));
            } else if (hasHome) {
                Home h = homes.get(homeId);
                meta.displayName(MessageUtil.colorize("&#1DC5E7Home #" + homeId));
                meta.lore(List.of(
                    MessageUtil.colorize("&7World: &f" + h.getWorld()),
                    MessageUtil.colorize("&7X: &f" + (int)h.getX() + " &7Y: &f" + (int)h.getY() + " &7Z: &f" + (int)h.getZ()),
                    MessageUtil.colorize("&7Click to teleport")
                ));
            } else {
                meta.displayName(MessageUtil.colorize("&7Home #" + homeId));
                meta.lore(List.of(MessageUtil.colorize("&7Not set")));
            }
            homeItem.setItemMeta(meta);
            inv.setItem(slot, homeItem);

            // Action item (set/delete)
            if (!locked) {
                ItemStack actionItem;
                if (hasHome) {
                    actionItem = new ItemStack(Material.BLUE_DYE);
                    ItemMeta am = actionItem.getItemMeta();
                    am.displayName(MessageUtil.colorize("&#FF0812Delete Home #" + homeId));
                    am.lore(List.of(MessageUtil.colorize("&fClick to delete")));
                    actionItem.setItemMeta(am);
                } else {
                    actionItem = new ItemStack(Material.GRAY_DYE);
                    ItemMeta am = actionItem.getItemMeta();
                    am.displayName(MessageUtil.colorize("&#00F986Set Home #" + homeId));
                    am.lore(List.of(MessageUtil.colorize("&fClick to set at your location")));
                    actionItem.setItemMeta(am);
                }
                inv.setItem(actionSlot, actionItem);
            }
        }

        player.openInventory(inv);
    }

    public static int getHomeIdFromSlot(int slot) {
        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (HOME_SLOTS[i] == slot) return i + 1;
        }
        return -1;
    }

    public static int getActionHomeIdFromSlot(int slot) {
        for (int i = 0; i < ACTION_SLOTS.length; i++) {
            if (ACTION_SLOTS[i] == slot) return i + 1;
        }
        return -1;
    }
}
