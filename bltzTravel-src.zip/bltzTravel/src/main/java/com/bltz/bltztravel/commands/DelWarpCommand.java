package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class DelWarpCommand implements CommandExecutor, TabCompleter {

    private final BltzTravel plugin;

    public DelWarpCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("bltztravel.warp.delete") && !sender.hasPermission("bltztravel.admin")) {
            sender.sendMessage(plugin.getLanguageManager().get("general.no-permission"));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(plugin.getLanguageManager().getPrefix() +
                    plugin.getLanguageManager().get("general.invalid-args", Map.of("usage", "/delwarp <n>")));
            return true;
        }

        String name = args[0];
        if (!plugin.getWarpManager().deleteWarp(name)) {
            sender.sendMessage(plugin.getLanguageManager().getPrefix() +
                    plugin.getLanguageManager().get("warp.not-found", Map.of("name", name)));
            return true;
        }

        sender.sendMessage(plugin.getLanguageManager().getPrefix() +
                plugin.getLanguageManager().get("warp.delete-success", Map.of("name", name)));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) {
            List<String> names = new ArrayList<>(plugin.getWarpManager().getWarpNames());
            String input = args[0].toLowerCase();
            names.removeIf(n -> !n.startsWith(input));
            return names;
        }
        return Collections.emptyList();
    }
}
