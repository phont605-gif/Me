package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class WarpAdminCommand implements CommandExecutor {
    private final BltzTravel plugin;
    private final boolean isSet;

    public WarpAdminCommand(BltzTravel plugin, boolean isSet) {
        this.plugin = plugin;
        this.isSet = isSet;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("only-player-command"));
            return true;
        }
        if (!player.hasPermission("bltztravel.admin")) {
            MessageUtil.send(player, plugin.getLanguageManager().get("no-permission"));
            return true;
        }
        if (args.length < 1) {
            MessageUtil.send(player, plugin.getLanguageManager().get(isSet ? "usage-setwarp" : "usage-delwarp"));
            return true;
        }
        String name = args[0];
        if (isSet) {
            plugin.getWarpManager().setWarp(name, player.getLocation());
            MessageUtil.send(player, plugin.getLanguageManager().get("warp-set", "warp", name));
        } else {
            if (!plugin.getWarpManager().deleteWarp(name)) {
                MessageUtil.send(player, plugin.getLanguageManager().get("warp-not-found", "warp", name));
            } else {
                MessageUtil.send(player, plugin.getLanguageManager().get("warp-deleted", "warp", name));
            }
        }
        return true;
    }
}
