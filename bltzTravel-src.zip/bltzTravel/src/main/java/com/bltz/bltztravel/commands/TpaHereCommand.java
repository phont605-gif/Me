package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.TeleportRequest;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class TpaHereCommand implements CommandExecutor, TabCompleter {

    private final BltzTravel plugin;

    public TpaHereCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        if (!player.hasPermission("bltztravel.tpa.use")) {
            plugin.getLanguageManager().sendMessage(player, "general.no-permission");
            return true;
        }

        if (args.length == 0) {
            plugin.getLanguageManager().sendMessage(player, "general.invalid-args", Map.of("usage", "/tpahere <player>"));
            return true;
        }

        // Handle "all" argument
        if (args[0].equalsIgnoreCase("all")) {
            if (!player.hasPermission("bltztravel.tpahere.all")) {
                plugin.getLanguageManager().sendMessage(player, "general.no-permission");
                return true;
            }
            long remaining = plugin.getTpaManager().getTpahereAllCooldownRemaining(player);
            if (remaining > 0) {
                plugin.getLanguageManager().sendMessage(player, "tpahere.cooldown", Map.of("time", String.valueOf(remaining)));
                return true;
            }
            plugin.getTpaManager().setTpahereAllCooldown(player);
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (!online.equals(player)) {
                    TeleportRequest req = new TeleportRequest(player, online, TeleportRequest.Type.TPAHERE);
                    plugin.getTpaManager().addRequest(req);
                    plugin.getLanguageManager().sendMessage(online, "tpahere.received", Map.of("player", player.getName()));
                }
            }
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || !target.isOnline()) {
            plugin.getLanguageManager().sendMessage(player, "general.player-not-found", Map.of("player", args[0]));
            return true;
        }

        if (target.equals(player)) {
            plugin.getLanguageManager().sendMessage(player, "tpa.self");
            return true;
        }

        TeleportRequest request = new TeleportRequest(player, target, TeleportRequest.Type.TPAHERE);

        if (plugin.getTpaManager().isTpaAuto(target)) {
            plugin.getLanguageManager().sendMessage(player, "tpa.accepted", Map.of("player", target.getName()));
            Map<String, String> ph = Map.of("delay", String.valueOf(plugin.getConfigManager().getTeleportDelay()),
                    "player", player.getName());
            plugin.getLanguageManager().sendMessage(target, "tpa.teleporting", ph);
            plugin.getTeleportManager().teleport(target, player.getLocation(), "tpa.teleporting", ph,
                    () -> plugin.getLanguageManager().sendMessage(target, "tpa.teleported", Map.of("player", player.getName())),
                    null);
            return true;
        }

        plugin.getTpaManager().addRequest(request);
        plugin.getLanguageManager().sendMessage(player, "tpahere.sent", Map.of("player", target.getName()));
        plugin.getLanguageManager().sendMessage(target, "tpahere.received", Map.of("player", player.getName()));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) {
            List<String> names = new ArrayList<>();
            names.add("all");
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.equals(sender)) names.add(p.getName());
            }
            String input = args[0].toLowerCase();
            names.removeIf(n -> !n.toLowerCase().startsWith(input));
            return names;
        }
        return Collections.emptyList();
    }
}
