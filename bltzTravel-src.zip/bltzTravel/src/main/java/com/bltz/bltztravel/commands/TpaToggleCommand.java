package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TpaToggleCommand implements CommandExecutor {

    private final BltzTravel plugin;

    public TpaToggleCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        boolean nowEnabled = plugin.getTpaManager().toggleTpa(player);
        plugin.getLanguageManager().sendMessage(player, nowEnabled ? "tpa.toggle-on" : "tpa.toggle-off");
        return true;
    }
}
