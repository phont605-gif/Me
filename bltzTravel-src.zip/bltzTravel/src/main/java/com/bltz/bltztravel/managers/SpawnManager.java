package com.bltz.bltztravel.managers;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

public class SpawnManager {
    private final BltzTravel plugin;
    private File dataFile;
    private FileConfiguration data;

    public SpawnManager(BltzTravel plugin) {
        this.plugin = plugin;
        dataFile = new File(plugin.getDataFolder(), "spawn.yml");
        if (!dataFile.exists()) {
            try { dataFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    public void save() {
        try { data.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }

    public void saveAll() {
        save();
    }

    public boolean isSet() {
        return data.contains("spawn.world");
    }

    public void setSpawn(Location loc) {
        data.set("spawn.world", loc.getWorld().getName());
        data.set("spawn.x", loc.getX());
        data.set("spawn.y", loc.getY());
        data.set("spawn.z", loc.getZ());
        data.set("spawn.yaw", loc.getYaw());
        data.set("spawn.pitch", loc.getPitch());
        save();
    }

    public Location getSpawn() {
        if (!isSet()) return null;
        var world = Bukkit.getWorld(data.getString("spawn.world"));
        if (world == null) return null;
        return new Location(world,
            data.getDouble("spawn.x"),
            data.getDouble("spawn.y"),
            data.getDouble("spawn.z"),
            (float) data.getDouble("spawn.yaw"),
            (float) data.getDouble("spawn.pitch")
        );
    }
}
