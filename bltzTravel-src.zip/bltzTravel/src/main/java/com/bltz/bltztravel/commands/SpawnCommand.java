package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.Location;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class SpawnCommand implements CommandExecutor {
    private final BltzTravel plugin;

    public SpawnCommand(BltzTravel plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("only-player-command"));
            return true;
        }
        Location spawn = plugin.getSpawnManager().getSpawn();
        if (spawn == null) {
            MessageUtil.send(player, plugin.getLanguageManager().get("spawn-not-set"));
            return true;
        }
        plugin.getTeleportManager().teleportWithDelay(player, spawn,
            plugin.getConfigManager().getTeleportDelay(),
            "spawn-actionbar-countdown", new String[]{});
        MessageUtil.send(player, plugin.getLanguageManager().get("teleported-to-spawn"));
        return true;
    }
}
