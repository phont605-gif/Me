package com.bltz.bltztravel.managers;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.Home;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class HomeManager {
    private final BltzTravel plugin;
    private File dataFile;
    private FileConfiguration data;

    public HomeManager(BltzTravel plugin) {
        this.plugin = plugin;
        dataFile = new File(plugin.getDataFolder(), "homes.yml");
        if (!dataFile.exists()) {
            try { dataFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    public void save() {
        try { data.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }

    public int getMaxHomes(Player player) {
        for (int i = 10; i >= 1; i--) {
            if (player.hasPermission("bltztravel.home." + i)) return i;
        }
        return 1;
    }

    public Map<Integer, Home> getHomes(Player player) {
        Map<Integer, Home> homes = new LinkedHashMap<>();
        String uuid = player.getUniqueId().toString();
        for (int i = 1; i <= 10; i++) {
            String path = uuid + ".home-" + i;
            if (data.contains(path)) {
                homes.put(i, new Home(
                    data.getString(path + ".world"),
                    data.getDouble(path + ".x"),
                    data.getDouble(path + ".y"),
                    data.getDouble(path + ".z"),
                    (float) data.getDouble(path + ".yaw"),
                    (float) data.getDouble(path + ".pitch")
                ));
            }
        }
        return homes;
    }

    public Home getHome(Player player, int id) {
        String path = player.getUniqueId() + ".home-" + id;
        if (!data.contains(path)) return null;
        return new Home(
            data.getString(path + ".world"),
            data.getDouble(path + ".x"),
            data.getDouble(path + ".y"),
            data.getDouble(path + ".z"),
            (float) data.getDouble(path + ".yaw"),
            (float) data.getDouble(path + ".pitch")
        );
    }

    public boolean setHome(Player player, int id) {
        if (id < 1 || id > 10) return false;
        if (!player.hasPermission("bltztravel.home." + id)) return false;
        Location loc = player.getLocation();
        String path = player.getUniqueId() + ".home-" + id;
        data.set(path + ".world", loc.getWorld().getName());
        data.set(path + ".x", loc.getX());
        data.set(path + ".y", loc.getY());
        data.set(path + ".z", loc.getZ());
        data.set(path + ".yaw", loc.getYaw());
        data.set(path + ".pitch", loc.getPitch());
        save();
        return true;
    }

    public boolean deleteHome(Player player, int id) {
        String path = player.getUniqueId() + ".home-" + id;
        if (!data.contains(path)) return false;
        data.set(path, null);
        save();
        return true;
    }

    public Location getHomeLocation(Player player, int id) {
        Home home = getHome(player, id);
        if (home == null) return null;
        var world = Bukkit.getWorld(home.getWorld());
        if (world == null) return null;
        return new Location(world, home.getX(), home.getY(), home.getZ(), home.getYaw(), home.getPitch());
    }
}
