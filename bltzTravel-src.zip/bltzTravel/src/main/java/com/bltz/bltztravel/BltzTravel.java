package com.bltz.bltztravel;

import com.bltz.bltztravel.commands.*;
import com.bltz.bltztravel.license.LicenseManager;
import com.bltz.bltztravel.listeners.InventoryListener;
import com.bltz.bltztravel.listeners.PlayerListener;
import com.bltz.bltztravel.managers.*;
import com.tcoded.folialib.FoliaLib;
import org.bukkit.plugin.java.JavaPlugin;

public class BltzTravel extends JavaPlugin {

    private static BltzTravel instance;
    private FoliaLib foliaLib;

    private ConfigManager configManager;
    private LanguageManager languageManager;
    private HomeManager homeManager;
    private WarpManager warpManager;
    private SpawnManager spawnManager;
    private TeleportManager teleportManager;
    private TpaManager tpaManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // =====================
        // LICENSE CHECK
        // =====================
        if (!checkLicense()) {
            getLogger().severe("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            getLogger().severe("  bltzTravel - INVALID LICENSE KEY!");
            getLogger().severe("  Please enter a valid license key");
            getLogger().severe("  in your config.yml under 'license-key'");
            getLogger().severe("  Contact: discord.gg/bltz to purchase");
            getLogger().severe("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getLogger().info("License verified! Starting bltzTravel...");

        foliaLib = new FoliaLib(this);

        configManager = new ConfigManager(this);
        languageManager = new LanguageManager(this);
        homeManager = new HomeManager(this);
        warpManager = new WarpManager(this);
        spawnManager = new SpawnManager(this);
        teleportManager = new TeleportManager(this);
        tpaManager = new TpaManager(this);

        registerCommands();

        getServer().getPluginManager().registerEvents(new InventoryListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        getLogger().info("bltzTravel v" + getDescription().getVersion() + " enabled!");
    }

    @Override
    public void onDisable() {
        if (homeManager != null) homeManager.saveAll();
        if (warpManager != null) warpManager.saveAll();
        if (spawnManager != null) spawnManager.saveAll();
        getLogger().info("bltzTravel disabled!");
    }

    private boolean checkLicense() {
        String licenseKey = getConfig().getString("license-key", "");
        if (licenseKey.isEmpty()) return false;
        return LicenseManager.verify(licenseKey);
    }

    private void registerCommands() {
        BltzTravelCommand mainCmd = new BltzTravelCommand(this);
        getCommand("bltztravel").setExecutor(mainCmd);
        getCommand("bltztravel").setTabCompleter(mainCmd);

        HomeCommand homeCmd = new HomeCommand(this);
        getCommand("home").setExecutor(homeCmd);
        getCommand("home").setTabCompleter(homeCmd);
        getCommand("homes").setExecutor(homeCmd);

        SetHomeCommand setHomeCmd = new SetHomeCommand(this);
        getCommand("sethome").setExecutor(setHomeCmd);
        getCommand("sethome").setTabCompleter(setHomeCmd);

        DelHomeCommand delHomeCmd = new DelHomeCommand(this);
        getCommand("delhome").setExecutor(delHomeCmd);
        getCommand("delhome").setTabCompleter(delHomeCmd);

        WarpCommand warpCmd = new WarpCommand(this);
        getCommand("warp").setExecutor(warpCmd);
        getCommand("warp").setTabCompleter(warpCmd);
        getCommand("warps").setExecutor(warpCmd);

        SetWarpCommand setWarpCmd = new SetWarpCommand(this);
        getCommand("setwarp").setExecutor(setWarpCmd);

        DelWarpCommand delWarpCmd = new DelWarpCommand(this);
        getCommand("delwarp").setExecutor(delWarpCmd);
        getCommand("delwarp").setTabCompleter(delWarpCmd);

        SpawnCommand spawnCmd = new SpawnCommand(this);
        getCommand("spawn").setExecutor(spawnCmd);

        SetSpawnCommand setSpawnCmd = new SetSpawnCommand(this);
        getCommand("setspawn").setExecutor(setSpawnCmd);

        TpaCommand tpaCmd = new TpaCommand(this);
        getCommand("tpa").setExecutor(tpaCmd);
        getCommand("tpa").setTabCompleter(tpaCmd);

        TpaHereCommand tpaHereCmd = new TpaHereCommand(this);
        getCommand("tpahere").setExecutor(tpaHereCmd);
        getCommand("tpahere").setTabCompleter(tpaHereCmd);

        TpAcceptCommand tpAcceptCmd = new TpAcceptCommand(this);
        getCommand("tpaccept").setExecutor(tpAcceptCmd);

        TpDenyCommand tpDenyCmd = new TpDenyCommand(this);
        getCommand("tpadeny").setExecutor(tpDenyCmd);

        TpaAutoCommand tpaAutoCmd = new TpaAutoCommand(this);
        getCommand("tpauto").setExecutor(tpaAutoCmd);

        TpaToggleCommand tpaToggleCmd = new TpaToggleCommand(this);
        getCommand("tpatoggle").setExecutor(tpaToggleCmd);
    }

    public static BltzTravel getInstance() { return instance; }
    public FoliaLib getFoliaLib() { return foliaLib; }
    public ConfigManager getConfigManager() { return configManager; }
    public LanguageManager getLanguageManager() { return languageManager; }
    public HomeManager getHomeManager() { return homeManager; }
    public WarpManager getWarpManager() { return warpManager; }
    public SpawnManager getSpawnManager() { return spawnManager; }
    public TeleportManager getTeleportManager() { return teleportManager; }
    public TpaManager getTpaManager() { return tpaManager; }
}
