package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class SetHomeCommand implements CommandExecutor, TabCompleter {

    private final BltzTravel plugin;

    public SetHomeCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        String homeName = args.length > 0 ? args[0] : "home";

        if (plugin.getHomeManager().hasHome(player, homeName)) {
            plugin.getHomeManager().setHomeOverwrite(player, homeName);
            plugin.getLanguageManager().sendMessage(player, "home.set-success", Map.of("name", homeName));
            return true;
        }

        int max = plugin.getHomeManager().getMaxHomes(player);
        if (plugin.getHomeManager().getHomeCount(player) >= max) {
            plugin.getLanguageManager().sendMessage(player, "home.limit-reached", Map.of("limit", String.valueOf(max)));
            return true;
        }

        plugin.getHomeManager().setHome(player, homeName);
        plugin.getLanguageManager().sendMessage(player, "home.set-success", Map.of("name", homeName));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return Collections.emptyList();
        if (args.length == 1) {
            List<String> names = new ArrayList<>(plugin.getHomeManager().getHomes(player).keySet());
            names.add("home");
            String input = args[0].toLowerCase();
            names.removeIf(n -> !n.startsWith(input));
            return names;
        }
        return Collections.emptyList();
    }
}
