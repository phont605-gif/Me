package com.bltz.bltztravel.listeners;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.gui.HomeGui;
import com.bltz.bltztravel.utils.MessageUtil;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;

public class InventoryListener implements Listener {
    private final BltzTravel plugin;

    public InventoryListener(BltzTravel plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getView() == null) return;

        String title = PlainTextComponentSerializer.plainText()
            .serialize(event.getView().title());

        if (!title.contains("Homes")) return;
        event.setCancelled(true);

        int slot = event.getRawSlot();

        // Click on home item -> teleport
        int homeId = HomeGui.getHomeIdFromSlot(slot);
        if (homeId != -1) {
            Location loc = plugin.getHomeManager().getHomeLocation(player, homeId);
            if (loc != null) {
                player.closeInventory();
                plugin.getTeleportManager().teleportWithDelay(player, loc,
                    plugin.getConfigManager().getTeleportDelay(),
                    "home-actionbar-countdown", new String[]{"id", String.valueOf(homeId)});
                MessageUtil.send(player, plugin.getLanguageManager().get("teleporting-home"));
            }
            return;
        }

        // Click on action item -> set/delete
        int actionId = HomeGui.getActionHomeIdFromSlot(slot);
        if (actionId != -1) {
            if (actionId > plugin.getHomeManager().getMaxHomes(player)) return;
            boolean hasHome = plugin.getHomeManager().getHome(player, actionId) != null;
            if (hasHome) {
                plugin.getHomeManager().deleteHome(player, actionId);
                MessageUtil.send(player, plugin.getLanguageManager().get("home-deleted", "id", String.valueOf(actionId)));
            } else {
                plugin.getHomeManager().setHome(player, actionId);
                MessageUtil.send(player, plugin.getLanguageManager().get("home-set", "id", String.valueOf(actionId)));
            }
            // Refresh GUI
            HomeGui.open(plugin, player);
        }
    }
}
