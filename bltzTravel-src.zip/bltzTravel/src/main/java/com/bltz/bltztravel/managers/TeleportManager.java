package com.bltz.bltztravel.managers;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.TeleportRequest;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class TeleportManager {
    private final BltzTravel plugin;

    // UUID of target -> list of requests
    private final Map<UUID, List<TeleportRequest>> pendingRequests = new HashMap<>();
    // Players who have auto-accept on
    private final Set<UUID> autoAccept = new HashSet<>();
    // Players who have tpa disabled
    private final Set<UUID> tpaDisabled = new HashSet<>();
    // /tpahere all cooldown
    private final Map<UUID, Long> tpahereAllCooldown = new HashMap<>();
    // Active teleport tasks (for cancellation on move)
    private final Map<UUID, BukkitRunnable> activeTasks = new HashMap<>();
    private final Map<UUID, Location> teleportStartLocations = new HashMap<>();

    public TeleportManager(BltzTravel plugin) {
        this.plugin = plugin;
    }

    public void sendRequest(Player requester, Player target, boolean isHere) {
        TeleportRequest request = new TeleportRequest(requester, target, isHere);
        pendingRequests.computeIfAbsent(target.getUniqueId(), k -> new ArrayList<>()).add(request);

        // Schedule expiry
        int timeout = plugin.getConfigManager().getRequestTimeout();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            List<TeleportRequest> reqs = pendingRequests.get(target.getUniqueId());
            if (reqs != null && reqs.remove(request)) {
                if (requester.isOnline()) {
                    MessageUtil.send(requester, plugin.getLanguageManager().get("request-timeout",
                        "player", target.getName()));
                }
            }
        }, timeout * 20L);
    }

    public List<TeleportRequest> getPendingRequests(Player target) {
        cleanExpired(target);
        return pendingRequests.getOrDefault(target.getUniqueId(), new ArrayList<>());
    }

    public TeleportRequest getRequestFrom(Player target, Player requester) {
        cleanExpired(target);
        List<TeleportRequest> reqs = pendingRequests.getOrDefault(target.getUniqueId(), new ArrayList<>());
        return reqs.stream().filter(r -> r.getRequester().equals(requester)).findFirst().orElse(null);
    }

    public TeleportRequest getLatestRequest(Player target) {
        cleanExpired(target);
        List<TeleportRequest> reqs = pendingRequests.getOrDefault(target.getUniqueId(), new ArrayList<>());
        return reqs.isEmpty() ? null : reqs.get(reqs.size() - 1);
    }

    public void removeRequest(Player target, TeleportRequest request) {
        List<TeleportRequest> reqs = pendingRequests.get(target.getUniqueId());
        if (reqs != null) reqs.remove(request);
    }

    private void cleanExpired(Player target) {
        int timeout = plugin.getConfigManager().getRequestTimeout();
        List<TeleportRequest> reqs = pendingRequests.get(target.getUniqueId());
        if (reqs != null) reqs.removeIf(r -> r.isExpired(timeout));
    }

    public void teleportWithDelay(Player player, Location destination, int delay,
                                   String actionBarKey, String[] placeholders) {
        cancelActiveTeleport(player);
        teleportStartLocations.put(player.getUniqueId(), player.getLocation().clone());

        BukkitRunnable task = new BukkitRunnable() {
            int remaining = delay;

            @Override
            public void run() {
                if (!player.isOnline()) { cancel(); return; }
                // Check if moved
                Location start = teleportStartLocations.get(player.getUniqueId());
                if (start != null && hasMoved(start, player.getLocation())) {
                    cancel();
                    activeTasks.remove(player.getUniqueId());
                    MessageUtil.send(player, plugin.getLanguageManager().get("teleport-cancelled-moved"));
                    return;
                }
                if (remaining > 0) {
                    String[] ph = buildPlaceholders(placeholders, remaining);
                    MessageUtil.sendActionBar(player, plugin.getLanguageManager().get(actionBarKey, ph));
                    plugin.getConfigManager();
                    player.playSound(player.getLocation(),
                        plugin.getConfigManager().getSound("tpa-countdown"),
                        plugin.getConfigManager().getSoundVolume("tpa-countdown"),
                        plugin.getConfigManager().getSoundPitch("tpa-countdown"));
                    remaining--;
                } else {
                    cancel();
                    activeTasks.remove(player.getUniqueId());
                    teleportStartLocations.remove(player.getUniqueId());
                    player.teleport(destination);
                }
            }
        };
        activeTasks.put(player.getUniqueId(), task);
        task.runTaskTimer(plugin, 0L, 20L);
    }

    public void cancelActiveTeleport(Player player) {
        BukkitRunnable task = activeTasks.remove(player.getUniqueId());
        if (task != null) task.cancel();
        teleportStartLocations.remove(player.getUniqueId());
    }

    private boolean hasMoved(Location a, Location b) {
        return Math.abs(a.getX() - b.getX()) > 0.1
            || Math.abs(a.getY() - b.getY()) > 0.1
            || Math.abs(a.getZ() - b.getZ()) > 0.1;
    }

    private String[] buildPlaceholders(String[] base, int seconds) {
        String[] result = Arrays.copyOf(base, base.length + 2);
        result[base.length] = "seconds";
        result[base.length + 1] = String.valueOf(seconds);
        return result;
    }

    public boolean isAutoAccept(Player player) { return autoAccept.contains(player.getUniqueId()); }
    public void toggleAutoAccept(Player player) {
        if (!autoAccept.remove(player.getUniqueId())) autoAccept.add(player.getUniqueId());
    }

    public boolean isTpaDisabled(Player player) { return tpaDisabled.contains(player.getUniqueId()); }
    public void toggleTpaDisabled(Player player) {
        if (!tpaDisabled.remove(player.getUniqueId())) tpaDisabled.add(player.getUniqueId());
    }

    public boolean isTpahereAllOnCooldown(Player player) {
        long last = tpahereAllCooldown.getOrDefault(player.getUniqueId(), 0L);
        return (System.currentTimeMillis() - last) / 1000 < plugin.getConfigManager().getTpaHereAllCooldown();
    }

    public int getTpahereAllRemainingCooldown(Player player) {
        long last = tpahereAllCooldown.getOrDefault(player.getUniqueId(), 0L);
        long elapsed = (System.currentTimeMillis() - last) / 1000;
        return (int) Math.max(0, plugin.getConfigManager().getTpaHereAllCooldown() - elapsed);
    }

    public void setTpahereAllCooldown(Player player) {
        tpahereAllCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }
}
