package com.bltz.bltztravel.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MessageUtil {

    public static Component colorize(String message) {
        if (message == null || message.isEmpty()) return Component.empty();
        // Handle &#RRGGBB hex colors and legacy & codes
        message = convertHex(message);
        return LegacyComponentSerializer.legacyAmpersand().deserialize(message);
    }

    private static String convertHex(String msg) {
        // Convert &#RRGGBB to §x§R§R§G§G§B§B
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < msg.length()) {
            if (i + 7 < msg.length() && msg.charAt(i) == '&' && msg.charAt(i + 1) == '#') {
                String hex = msg.substring(i + 2, i + 8);
                if (hex.matches("[0-9a-fA-F]{6}")) {
                    sb.append("§x");
                    for (char c : hex.toCharArray()) sb.append('§').append(c);
                    i += 8;
                    continue;
                }
            }
            sb.append(msg.charAt(i));
            i++;
        }
        return sb.toString();
    }

    public static void send(CommandSender sender, String message) {
        if (message == null || message.isEmpty()) return;
        sender.sendMessage(colorize(message));
    }

    public static void sendActionBar(Player player, String message) {
        player.sendActionBar(colorize(message));
    }
}
