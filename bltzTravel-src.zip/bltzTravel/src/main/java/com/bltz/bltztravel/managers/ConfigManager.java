package com.bltz.bltztravel.managers;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.Sound;

public class ConfigManager {
    private final BltzTravel plugin;

    public ConfigManager(BltzTravel plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        plugin.reloadConfig();
    }

    public int getRequestTimeout() {
        return plugin.getConfig().getInt("settings.request-timeout", 120);
    }

    public int getTeleportDelay() {
        return plugin.getConfig().getInt("settings.teleport-delay", 5);
    }

    public int getTpaHereAllCooldown() {
        return plugin.getConfig().getInt("settings.tpahere-all-cooldown", 600);
    }

    public boolean isSpawnOnJoin() {
        return plugin.getConfig().getBoolean("settings.spawn-on-join", true);
    }

    public String getWarpInstantWorld() {
        return plugin.getConfig().getString("settings.warp.instant-teleport-world", "lobby");
    }

    public int getWarpTeleportDelay() {
        return plugin.getConfig().getInt("settings.warp.teleport-delay", 5);
    }

    public Sound getSound(String key) {
        String name = plugin.getConfig().getString("settings.sound." + key + ".name", "UI_BUTTON_CLICK");
        try {
            return Sound.valueOf(name);
        } catch (Exception e) {
            return Sound.UI_BUTTON_CLICK;
        }
    }

    public float getSoundVolume(String key) {
        return (float) plugin.getConfig().getDouble("settings.sound." + key + ".volume", 1.0);
    }

    public float getSoundPitch(String key) {
        return (float) plugin.getConfig().getDouble("settings.sound." + key + ".pitch", 1.0);
    }
}
