package com.bltz.bltztravel.models;

import org.bukkit.entity.Player;

public class TeleportRequest {
    public enum Type { TPA, TPAHERE }

    private final Player sender;
    private final Player target;
    private final Type type;
    private final long timestamp;

    public TeleportRequest(Player sender, Player target, Type type) {
        this.sender = sender;
        this.target = target;
        this.type = type;
        this.timestamp = System.currentTimeMillis();
    }

    public Player getSender() { return sender; }
    public Player getTarget() { return target; }
    public Type getType() { return type; }
    public long getTimestamp() { return timestamp; }

    public boolean isExpired(long timeoutSeconds) {
        return (System.currentTimeMillis() - timestamp) > (timeoutSeconds * 1000L);
    }
}
