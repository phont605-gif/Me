package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.gui.HomeGui;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.Location;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class HomeCommand implements CommandExecutor, TabCompleter {
    private final BltzTravel plugin;

    public HomeCommand(BltzTravel plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("only-player-command"));
            return true;
        }

        // /home [id] - open GUI or teleport directly
        if (args.length == 0) {
            HomeGui.open(plugin, player);
            return true;
        }

        // /home <id>
        try {
            int id = Integer.parseInt(args[0]);
            Location loc = plugin.getHomeManager().getHomeLocation(player, id);
            if (loc == null) {
                MessageUtil.send(player, plugin.getLanguageManager().get("home-not-found", "id", args[0]));
                return true;
            }
            if (loc.getWorld() == null) {
                MessageUtil.send(player, plugin.getLanguageManager().get("home-world-not-found"));
                return true;
            }
            plugin.getTeleportManager().teleportWithDelay(player, loc,
                plugin.getConfigManager().getTeleportDelay(),
                "home-actionbar-countdown", new String[]{"id", args[0]});
            MessageUtil.send(player, plugin.getLanguageManager().get("teleporting-home"));
        } catch (NumberFormatException e) {
            MessageUtil.send(player, plugin.getLanguageManager().get("home-not-found", "id", args[0]));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1 && sender instanceof Player player) {
            List<String> list = new ArrayList<>();
            var homes = plugin.getHomeManager().getHomes(player);
            homes.keySet().forEach(id -> list.add(String.valueOf(id)));
            return list;
        }
        return new ArrayList<>();
    }
}
