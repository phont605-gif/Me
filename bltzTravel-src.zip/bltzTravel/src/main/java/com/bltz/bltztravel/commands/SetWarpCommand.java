package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class SetWarpCommand implements CommandExecutor {

    private final BltzTravel plugin;

    public SetWarpCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        if (!player.hasPermission("bltztravel.warp.set") && !player.hasPermission("bltztravel.admin")) {
            plugin.getLanguageManager().sendMessage(player, "general.no-permission");
            return true;
        }

        if (args.length == 0) {
            plugin.getLanguageManager().sendMessage(player, "general.invalid-args", Map.of("usage", "/setwarp <n>"));
            return true;
        }

        String name = args[0];
        if (plugin.getWarpManager().warpExists(name)) {
            plugin.getLanguageManager().sendMessage(player, "warp.already-exists", Map.of("name", name));
            return true;
        }

        plugin.getWarpManager().createWarp(name, player);
        plugin.getLanguageManager().sendMessage(player, "warp.set-success", Map.of("name", name));
        return true;
    }
}
