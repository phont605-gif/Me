package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.TeleportRequest;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class TpaCommand implements CommandExecutor, TabCompleter {

    private final BltzTravel plugin;

    public TpaCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        if (!player.hasPermission("bltztravel.tpa.use")) {
            plugin.getLanguageManager().sendMessage(player, "general.no-permission");
            return true;
        }

        if (args.length == 0) {
            plugin.getLanguageManager().sendMessage(player, "general.invalid-args", Map.of("usage", "/tpa <player>"));
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || !target.isOnline()) {
            plugin.getLanguageManager().sendMessage(player, "general.player-not-found", Map.of("player", args[0]));
            return true;
        }

        if (target.equals(player)) {
            plugin.getLanguageManager().sendMessage(player, "tpa.self");
            return true;
        }

        if (plugin.getTpaManager().isTpaDisabled(target) && !player.hasPermission("bltztravel.tpahere.all")) {
            plugin.getLanguageManager().sendMessage(player, "tpa.disabled", Map.of("player", target.getName()));
            return true;
        }

        if (plugin.getTpaManager().hasSentRequest(player)) {
            plugin.getLanguageManager().sendMessage(player, "tpa.already-sent");
            return true;
        }

        TeleportRequest request = new TeleportRequest(player, target, TeleportRequest.Type.TPA);

        // Auto-accept
        if (plugin.getTpaManager().isTpaAuto(target)) {
            plugin.getLanguageManager().sendMessage(player, "tpa.accepted", Map.of("player", target.getName()));
            Map<String, String> ph = Map.of("delay", String.valueOf(plugin.getConfigManager().getTeleportDelay()),
                    "player", target.getName());
            plugin.getLanguageManager().sendMessage(player, "tpa.teleporting", ph);
            plugin.getTeleportManager().teleport(player, target.getLocation(), "tpa.teleporting", ph,
                    () -> plugin.getLanguageManager().sendMessage(player, "tpa.teleported", Map.of("player", target.getName())),
                    null);
            return true;
        }

        plugin.getTpaManager().addRequest(request);
        plugin.getLanguageManager().sendMessage(player, "tpa.sent", Map.of("player", target.getName()));
        plugin.getLanguageManager().sendMessage(target, "tpa.received", Map.of("player", player.getName()));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.equals(sender)) names.add(p.getName());
            }
            String input = args[0].toLowerCase();
            names.removeIf(n -> !n.toLowerCase().startsWith(input));
            return names;
        }
        return Collections.emptyList();
    }
}
