package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

public class BltzTravelCommand implements CommandExecutor, TabCompleter {
    private final BltzTravel plugin;

    public BltzTravelCommand(BltzTravel plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("bltztravel.admin")) {
            MessageUtil.send(sender, plugin.getLanguageManager().get("no-permission"));
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            try {
                plugin.getConfigManager().reload();
                plugin.getLanguageManager().load();
                MessageUtil.send(sender, plugin.getLanguageManager().get("reload-success"));
            } catch (Exception e) {
                MessageUtil.send(sender, plugin.getLanguageManager().get("reload-error", "error", e.getMessage()));
            }
            return true;
        }
        MessageUtil.send(sender, plugin.getLanguageManager().get("plugin-info", "version", plugin.getDescription().getVersion()));
        MessageUtil.send(sender, plugin.getLanguageManager().get("reload-usage"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) return List.of("reload");
        return new ArrayList<>();
    }
}
