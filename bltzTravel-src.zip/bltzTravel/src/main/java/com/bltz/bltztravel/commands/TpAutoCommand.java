package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class TpAutoCommand implements CommandExecutor {
    private final BltzTravel plugin;

    public TpAutoCommand(BltzTravel plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("only-player-command"));
            return true;
        }
        plugin.getTeleportManager().toggleAutoAccept(player);
        boolean isOn = plugin.getTeleportManager().isAutoAccept(player);
        MessageUtil.send(player, plugin.getLanguageManager().get(isOn ? "tpauto-enabled" : "tpauto-disabled"));
        return true;
    }
}
