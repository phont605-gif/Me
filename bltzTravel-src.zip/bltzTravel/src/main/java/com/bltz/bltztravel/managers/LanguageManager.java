package com.bltz.bltztravel.managers;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

public class LanguageManager {
    private final BltzTravel plugin;
    private FileConfiguration langConfig;

    public LanguageManager(BltzTravel plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        String lang = plugin.getConfig().getString("language", "en");
        String fileName = "language/language_" + lang + ".yml";
        File file = new File(plugin.getDataFolder(), fileName);

        if (!file.exists()) {
            plugin.saveResource(fileName, false);
        }

        langConfig = YamlConfiguration.loadConfiguration(file);
        // Fallback to embedded
        InputStream defStream = plugin.getResource(fileName);
        if (defStream != null) {
            YamlConfiguration def = YamlConfiguration.loadConfiguration(
                new InputStreamReader(defStream, StandardCharsets.UTF_8));
            langConfig.setDefaults(def);
        }
    }

    public String get(String key) {
        String prefix = langConfig.getString("messages.prefix", "");
        String msg = langConfig.getString("messages." + key, "&c[bltzTravel] Missing message: " + key);
        return prefix + msg;
    }

    public String get(String key, String... placeholders) {
        String msg = get(key);
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            msg = msg.replace("{" + placeholders[i] + "}", placeholders[i + 1]);
        }
        return msg;
    }
}
