package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.Location;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

public class WarpCommand implements CommandExecutor, TabCompleter {
    private final BltzTravel plugin;

    public WarpCommand(BltzTravel plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("only-player-command"));
            return true;
        }
        List<String> warps = plugin.getWarpManager().getWarpNames();

        if (args.length == 0) {
            if (warps.isEmpty()) {
                MessageUtil.send(player, plugin.getLanguageManager().get("usage-warp"));
            } else {
                MessageUtil.send(player, plugin.getLanguageManager().get("available-warps",
                    "warps", String.join(", ", warps)));
            }
            return true;
        }

        Location loc = plugin.getWarpManager().getWarpLocation(args[0]);
        if (loc == null) {
            MessageUtil.send(player, plugin.getLanguageManager().get("warp-not-found", "warp", args[0]));
            return true;
        }

        String warpWorld = loc.getWorld() != null ? loc.getWorld().getName() : "";
        String instantWorld = plugin.getConfigManager().getWarpInstantWorld();
        int delay = warpWorld.equalsIgnoreCase(instantWorld) ? 0 : plugin.getConfigManager().getWarpTeleportDelay();

        if (delay <= 0) {
            player.teleport(loc);
            MessageUtil.send(player, plugin.getLanguageManager().get("teleport-warp-success", "warp", args[0]));
        } else {
            MessageUtil.send(player, plugin.getLanguageManager().get("teleporting-warp", "warp", args[0]));
            plugin.getTeleportManager().teleportWithDelay(player, loc, delay,
                "warp-actionbar-countdown", new String[]{"warp", args[0]});
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) return plugin.getWarpManager().getWarpNames();
        return new ArrayList<>();
    }
}
