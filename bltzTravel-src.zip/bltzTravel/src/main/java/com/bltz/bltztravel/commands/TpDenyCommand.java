package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.TeleportRequest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class TpDenyCommand implements CommandExecutor {

    private final BltzTravel plugin;

    public TpDenyCommand(BltzTravel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("general.player-only"));
            return true;
        }

        TeleportRequest request = plugin.getTpaManager().removeRequest(player);
        if (request == null) {
            plugin.getLanguageManager().sendMessage(player, "tpa.no-request");
            return true;
        }

        Player requester = request.getSender();
        plugin.getLanguageManager().sendMessage(player, "tpa.you-denied", Map.of("player", requester.getName()));
        if (requester.isOnline()) {
            plugin.getLanguageManager().sendMessage(requester, "tpa.denied", Map.of("player", player.getName()));
        }
        return true;
    }
}
