package com.bltz.bltztravel.managers;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.TeleportRequest;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TpaManager {

    private final BltzTravel plugin;
    private final Map<UUID, TeleportRequest> pendingRequests = new ConcurrentHashMap<>();
    private final Set<UUID> tpaDisabled = new HashSet<>();
    private final Set<UUID> tpaAuto = new HashSet<>();
    private final Map<UUID, Long> tpahereAllCooldowns = new ConcurrentHashMap<>();

    public TpaManager(BltzTravel plugin) {
        this.plugin = plugin;
    }

    public void addRequest(TeleportRequest request) {
        pendingRequests.put(request.getTarget().getUniqueId(), request);
    }

    public TeleportRequest getRequest(Player target) {
        TeleportRequest req = pendingRequests.get(target.getUniqueId());
        if (req == null) return null;
        if (req.isExpired(plugin.getConfigManager().getRequestTimeout())) {
            pendingRequests.remove(target.getUniqueId());
            return null;
        }
        return req;
    }

    public TeleportRequest removeRequest(Player target) {
        return pendingRequests.remove(target.getUniqueId());
    }

    public boolean hasPendingRequest(Player target) { return getRequest(target) != null; }

    public boolean hasSentRequest(Player sender) {
        for (TeleportRequest req : pendingRequests.values()) {
            if (req.getSender().getUniqueId().equals(sender.getUniqueId())) return true;
        }
        return false;
    }

    public boolean isTpaDisabled(Player player) { return tpaDisabled.contains(player.getUniqueId()); }

    public boolean toggleTpa(Player player) {
        if (tpaDisabled.contains(player.getUniqueId())) {
            tpaDisabled.remove(player.getUniqueId());
            return true;
        } else {
            tpaDisabled.add(player.getUniqueId());
            return false;
        }
    }

    public boolean isTpaAuto(Player player) { return tpaAuto.contains(player.getUniqueId()); }

    public boolean toggleTpaAuto(Player player) {
        if (tpaAuto.contains(player.getUniqueId())) {
            tpaAuto.remove(player.getUniqueId());
            return false;
        } else {
            tpaAuto.add(player.getUniqueId());
            return true;
        }
    }

    public long getTpahereAllCooldownRemaining(Player player) {
        Long ts = tpahereAllCooldowns.get(player.getUniqueId());
        if (ts == null) return 0;
        long elapsed = (System.currentTimeMillis() - ts) / 1000;
        long cooldown = plugin.getConfigManager().getTpaHereAllCooldown();
        return Math.max(0, cooldown - elapsed);
    }

    public void setTpahereAllCooldown(Player player) {
        tpahereAllCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public void cleanupPlayer(Player player) {
        pendingRequests.remove(player.getUniqueId());
    }
}
