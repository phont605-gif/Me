package com.bltz.bltztravel.managers;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.models.Warp;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class WarpManager {
    private final BltzTravel plugin;
    private File dataFile;
    private FileConfiguration data;

    public WarpManager(BltzTravel plugin) {
        this.plugin = plugin;
        dataFile = new File(plugin.getDataFolder(), "warps.yml");
        if (!dataFile.exists()) {
            try { dataFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    public void save() {
        try { data.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }

    public List<String> getWarpNames() {
        if (data.getConfigurationSection("warps") == null) return new ArrayList<>();
        return new ArrayList<>(data.getConfigurationSection("warps").getKeys(false));
    }

    public Warp getWarp(String name) {
        String path = "warps." + name;
        if (!data.contains(path)) return null;
        return new Warp(name,
            data.getString(path + ".world"),
            data.getDouble(path + ".x"),
            data.getDouble(path + ".y"),
            data.getDouble(path + ".z"),
            (float) data.getDouble(path + ".yaw"),
            (float) data.getDouble(path + ".pitch")
        );
    }

    public void setWarp(String name, Location loc) {
        String path = "warps." + name;
        data.set(path + ".world", loc.getWorld().getName());
        data.set(path + ".x", loc.getX());
        data.set(path + ".y", loc.getY());
        data.set(path + ".z", loc.getZ());
        data.set(path + ".yaw", loc.getYaw());
        data.set(path + ".pitch", loc.getPitch());
        save();
    }

    public boolean deleteWarp(String name) {
        if (!data.contains("warps." + name)) return false;
        data.set("warps." + name, null);
        save();
        return true;
    }

    public Location getWarpLocation(String name) {
        Warp warp = getWarp(name);
        if (warp == null) return null;
        var world = Bukkit.getWorld(warp.getWorld());
        if (world == null) return null;
        return new Location(world, warp.getX(), warp.getY(), warp.getZ(), warp.getYaw(), warp.getPitch());
    }
}
