package com.bltz.bltztravel.commands;

import com.bltz.bltztravel.BltzTravel;
import com.bltz.bltztravel.utils.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SpawnAdminCommand implements CommandExecutor {
    private final BltzTravel plugin;

    public SpawnAdminCommand(BltzTravel plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getLanguageManager().get("only-player-command"));
            return true;
        }
        if (!player.hasPermission("bltztravel.admin")) {
            MessageUtil.send(player, plugin.getLanguageManager().get("no-permission"));
            return true;
        }
        plugin.getSpawnManager().setSpawn(player.getLocation());
        MessageUtil.send(player, plugin.getLanguageManager().get("spawn-set"));
        return true;
    }
}
