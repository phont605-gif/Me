package com.bltz.bltztravel.listeners;

import com.bltz.bltztravel.BltzTravel;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerListener implements Listener {
    private final BltzTravel plugin;

    public PlayerListener(BltzTravel plugin) { this.plugin = plugin; }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        if (!plugin.getConfigManager().isSpawnOnJoin()) return;
        var spawn = plugin.getSpawnManager().getSpawn();
        if (spawn == null) return;
        // Teleport async to avoid potential issues
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            event.getPlayer().teleport(spawn);
        }, 5L);
    }
}
